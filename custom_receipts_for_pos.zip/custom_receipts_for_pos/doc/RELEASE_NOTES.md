## Module <custom_receipts_for_pos>

#### 30.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial Commit for POS Receipt Design

#### 04.12.2024
#### Version 18.0.1.0.1
##### BUG FIX
- BUG FIX

#### 28.05.2025
#### Version 18.0.1.0.2
##### BUG FIX
- Fixed the issues in the custom receipts which show error while printing the receipts.
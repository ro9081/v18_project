///** @odoo-module **/
//
//import { patch } from "@web/core/utils/patch";
//import { ConfirmationDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
//import { useService } from "@web/core/utils/hooks";
//import { TicketScreen } from "@point_of_sale/app/screens/ticket_screen/ticket_screen";
//import { rpc } from "@web/core/network/rpc";
//
//patch(TicketScreen.prototype, {
//    async onClickPopup() {
//        console.log("Testing====================");
//          const order = this.getSelectedOrder?.() || this.selectedOrder;
//        console.log("Selected Order:=================", order);
//        const accountMove = order?.raw?.account_move;
//        console.log("Account Move ID:==============", accountMove);
//            try {
//                    console.log("Calling API to create copy invoice for move ID:", accountMove);
//                    const result = await rpc("/pos/create_copy_invoice", { move_id: accountMove });
//                    console.log("Invoice copied. New Invoice Number:", result["Invoice Number"]);
//                } catch (error) {
//                    console.error("Error during RPC call:", error);
//                    if (error?.message) {
//                        console.error("Server error:", error.message);
//                    }
//                }
//        console.log("End of onClickPopup");
//        console.log("print error==================");
//    }
//});


/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { TicketScreen } from "@point_of_sale/app/screens/ticket_screen/ticket_screen";
import { rpc } from "@web/core/network/rpc";

patch(TicketScreen.prototype, {

    async onClickPopup() {
        const order = this.getSelectedOrder?.() || this.selectedOrder;

        if (!order) {
            console.log("No order selected.");
            return;
        }
        try {
            await this.doCopySale(order);

            if (!order.backendId) {
                await this.pos.syncOrder(order);
            }

            if (order.backendId) {
                await this.report.printTicket("point_of_sale.pos_ticket", order.backendId);
            } else {
                console.log("Cannot print receipt: order is not synced to backend.");
            }
        } catch (error) {
            console.log("Error during RPC or print:", error);
        }
    },
    doCopySale: async function (order) {
        try {
            const accountMove = order?.raw?.account_move;
            console.log("Calling /pos/create_copy_invoice with move_id:", accountMove);

            if (!accountMove) {
                console.log("No account_move found for this order.");
                return;
            }
            const result = await rpc("/pos/create_copy_invoice", { move_id: accountMove });
            console.log("Copy created:================", result);

            if (!order.backendId) {
                await this.pos.syncOrder(order);
            }
        } catch (error) {
            console.log("Copy failed:===================", error);
            if (error?.data?.message) {
                console.log("Odoo Server Error:", error.data.message);
            }
        }
    },
});


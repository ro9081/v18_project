from odoo import http
from odoo.http import request
from odoo.exceptions import ValidationError

class PosCustomSaleInvoiceController(http.Controller):

    @http.route('/pos/create_copy_invoice', type='json', auth='user')
    def create_sale_and_refund_copy_invoice(self, move_id):
        print('==================== inside contoller')
        move = request.env['account.move'].sudo().browse(move_id)
        if not move.exists():
            return {'error': 'Invoice not found.'}
        try:
            move.action_copy_sale_and_refund_invoice()
            return {
                'success': True,
                'Invoice Number': move.name
            }
        except ValidationError as ve:
            return {
                'success': False,
                'error': str(ve)
            }
        except Exception as e:
            return {
                'success': False,
                'error': f"Unexpected error: {e}"
            }

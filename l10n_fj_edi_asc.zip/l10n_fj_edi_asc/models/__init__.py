# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_move
# from . import res_company
# from . import res_config_settings
from . import account_edi_format
# from . import vsdc_tax_label
from . import hr_employee
from . import pos_order
from . import account_tax
from . import pos_config
from . import vms_payment_type
from . import pos_payment_method
from . import res_partner
